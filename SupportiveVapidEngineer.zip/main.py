a=1
while (a<=20):
  Name=input("Enter your name: ")
  a=a+1