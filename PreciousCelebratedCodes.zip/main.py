a="o"
while(a!=" adios"):
  a=input("insert the password: ")
  print("access guaranteed")