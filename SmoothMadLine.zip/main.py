a=1
while(a<=15):
  input('ticket')
  a=a+1