#input 

print('reprobados')

print('dime como te llamas:')

nombre=input()

print('hola',nombre)


edad=input('cual es tu edad: ')

print('tienes',edad,'años')