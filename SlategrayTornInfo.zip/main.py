#codeone
comparator=1
while(comparator<=20):
  nombre=input('cual es tu nombre?' )
  print('hol',nombre )
  