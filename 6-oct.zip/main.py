x=5

reprobados="9C"

jamon=10

reprobados="muchos"

print("el grupo mas reprobado es:", reprobados)

muchos_reprobados="9b"


nombre="alejandra"
print("me llamo: ", nombre)


grupo="9b"
print("mi grupo: ", grupo)
      
comidafavorita="chocolate"
print("comida favirita: ", comidafavorita)

tecuento="no lamo mesas "
print("te cuento que:", tecuento)


nombre="romina"
print("me llamo: ", nombre)


grupo="9b"
print("mi grupo: ", grupo)
      
comidafavorita="shusi"
print("comida favirita: ", comidafavorita)

tecuento="va en 9"
print("te cuento que:", tecuento)