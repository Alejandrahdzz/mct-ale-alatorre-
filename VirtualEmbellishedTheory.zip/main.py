numero=input('ingresa numero:')
print("tu numero de la suerte no es:",numero)

nombre=input('ingrese su nombre:')
print('saludos',nombre)

comida=input('ingresa comida favorita')
print('comida favotita es',comida)

grado=input('9')
grupo=input('B')